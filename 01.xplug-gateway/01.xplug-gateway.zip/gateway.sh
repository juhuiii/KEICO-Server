#!/bin/bash

node --max-old-space-size=256 src/app.js
