systemctl stop xpiaGateway.service
