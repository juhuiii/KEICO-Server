tail -F /var/log/syslog | grep gateway
