systemctl stop xpiaGateway.service
systemctl start xpiaGateway.service
