systemctl status xpiaGateway.service
